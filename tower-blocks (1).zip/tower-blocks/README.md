# Tower Blocks

A Pen created on CodePen.io. Original URL: [https://codepen.io/ste-vg/pen/ppLQNW](https://codepen.io/ste-vg/pen/ppLQNW).

Tower building game. Place blocks by clicking, tapping or spacebarring. 

A clone of Stack https://itunes.apple.com/us/app/stack/id1080487957?mt=8